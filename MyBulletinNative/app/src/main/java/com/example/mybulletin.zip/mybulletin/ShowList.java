package com.example.mybulletin;

import android.app.PendingIntent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mybulletin.objects.Course;
import com.example.mybulletin.objects.Exercise;
import com.example.mybulletin.objects.Student;
import com.google.gson.Gson;

import java.util.ArrayList;

public class ShowList extends AppCompatActivity {

    Exercise exerciseSelected = SelectExercise.exerciseSelected;
    AttandanceListAdapter adapter;
    ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list);

        mListView = (ListView) findViewById(R.id.listView);

        if(exerciseSelected == null){
            exerciseSelected = StudentAttandanceActivity.exercise1;
        }

        adapter = new AttandanceListAdapter(this, R.layout.adapter_view_layout, exerciseSelected.studentsPresence);
        mListView.setAdapter(adapter);
    }


}
