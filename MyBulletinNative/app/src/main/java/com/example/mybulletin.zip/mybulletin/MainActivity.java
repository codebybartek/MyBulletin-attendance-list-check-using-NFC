


package com.example.mybulletin;

import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.icu.text.DateFormat;
import android.icu.util.Calendar;
import android.nfc.NfcAdapter;
import android.nfc.tech.IsoDep;
import android.nfc.tech.MifareClassic;
import android.nfc.tech.MifareUltralight;
import android.nfc.tech.Ndef;
import android.nfc.tech.NfcA;
import android.nfc.tech.NfcB;
import android.nfc.tech.NfcF;
import android.nfc.tech.NfcV;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.mybulletin.objects.Course;
import com.example.mybulletin.objects.Group;
import com.example.mybulletin.objects.Professor;
import com.example.mybulletin.objects.Student;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static java.lang.String.join;
import static java.lang.Thread.sleep;

public class MainActivity extends AppCompatActivity {


    public static ArrayList<Student> students = new ArrayList<>();
    public static ArrayList<Course> courses = new ArrayList<>();

    private String courses_url = "http://vps669485.ovh.net/api/courses";
    private String login_url = "http://vps669485.ovh.net/api/loginMobileApp";
    public String token;

    public static Professor professor1;
    public Group group;

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;

    // list of NFC technologies detected:
    private final String[][] techList = new String[][] {
            new String[] {
                    NfcA.class.getName(),
                    NfcB.class.getName(),
                    NfcF.class.getName(),
                    NfcV.class.getName(),
                    IsoDep.class.getName(),
                    MifareClassic.class.getName(),
                    MifareUltralight.class.getName(), Ndef.class.getName()
            }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        professor1 = new Professor( 1,"Ivan Martinez","04441C4ABF5980", "21#D#@%F313D2", courses);

        getToken();
        try {
            sleep(1000);
            loadCourses();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);

    }

    @Override
    protected void onResume() {
        super.onResume();

        IntentFilter filter = new IntentFilter();
        filter.addAction(NfcAdapter.ACTION_TAG_DISCOVERED);
        filter.addAction(NfcAdapter.ACTION_NDEF_DISCOVERED);
        filter.addAction(NfcAdapter.ACTION_TECH_DISCOVERED);
        // enabling foreground dispatch for getting intent from NFC event:

        nfcAdapter.enableForegroundDispatch(this, pendingIntent, new IntentFilter[]{filter}, this.techList);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // disabling foreground dispatch:
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        nfcAdapter.disableForegroundDispatch(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        if (intent.getAction().equals(NfcAdapter.ACTION_TAG_DISCOVERED)) {
            String tag = ByteArrayToHexString(intent.getByteArrayExtra(NfcAdapter.EXTRA_ID));
            Toast.makeText(this, tag, Toast.LENGTH_SHORT).show();
            if (tag.equals("04441C4ABF5980") || tag.equals("047B5092E05B80")) {
                Intent intentt = new Intent(this, SelectYourCourse.class);
                startActivity(intentt);
            }
        }
    }

    /*private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("task list", null);
        Type type = new TypeToken<ArrayList<Course>>() {}.getType();
        courses = gson.fromJson(json, type);


        if (courses.isEmpty()) {
            Student student1 = new Student("Bartek Kozieł", "1","04441C4ABF5980", false, "");
            Student student2 = new Student("Tom Cruise", "2","047B5092E05B80", false, "");
            Student student3 = new Student("Yevhenii Lashutko", "3","044F181A395780", false, "");
            Student student4 = new Student("Bartek Kozieł4", "4","047B5E00925B80", false, "");

            students.add(student1);
            students.add(student2);
            students.add(student3);
            students.add(student4);

            Group group1 = new Group("11",students);
            Group group2 = new Group("12",students);
            Group group3 = new Group("13",students);

            Course wabaplication = new Course("Web-application",  group1);
            Course network = new Course("Network-Security",  group1);
            Course company = new Course("Create Company",  group1);

            courses.add(wabaplication);
            courses.add(network);
            courses.add(company);
        }else{
            students = courses.get(0).group.students;
            Group group1 = new Group("11",students);
            Group group2 = new Group("12",students);
            Group group3 = new Group("13",students);

        }

        loadCourses();

    }*/

    private String ByteArrayToHexString(byte [] inarray) {
        int i, j, in;
        String [] hex = {"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"};
        String out= "";

        for(j = 0 ; j < inarray.length ; ++j)
        {
            in = (int) inarray[j] & 0xff;
            i = (in >> 4) & 0x0f;
            out += hex[i];
            i = in & 0x0f;
            out += hex[i];
        }
        return out;
    }

    private void getToken() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, login_url,
                new Response.Listener<String>() {


                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject obj = new JSONObject(response);
                            token = obj.getString("userToken");

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                //Display error message whenever an error occurs
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        })

        {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("tagId", professor1.getTagId());
                params.put("mobile_token", professor1.getMobileToken());

                return params;
            }
        };

        // Access the RequestQueue through your singleton class.
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        //adding the string request to request queue
        requestQueue.add(stringRequest);
    }

    private void loadCourses() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, courses_url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject obj = new JSONObject(response);
                            JSONArray responseArray = obj.getJSONArray("data");

                            for (int i = 0; i < responseArray.length(); i++) {
                                JSONObject ObjectData = responseArray.getJSONObject(i);

                                Integer courseId = ObjectData.getInt("id");
                                String courseName = ObjectData.getString("name");

                                JSONArray responseArrayGroup = ObjectData.getJSONArray("group");

                                JSONObject ObjectDataGroup = responseArrayGroup.getJSONObject(0);
                                Integer groupId = ObjectDataGroup.getInt("group_id");
                                String groupName = ObjectDataGroup.getString("name");

                                addCourse(groupId, courseName);

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                //Display error message whenever an error occurs
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        })

        {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }
        };

        // Access the RequestQueue through your singleton class.
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        //adding the string request to request queue
        requestQueue.add(stringRequest);
    }



    private void addCourse(int groupId, final String courseName) {
        String groups_url = "http://vps669485.ovh.net/api/groups/" + groupId;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, groups_url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject obj = new JSONObject(response);

                            JSONArray responseArray = obj.getJSONArray("data");

                            for (int i = 0; i < responseArray.length(); i++) {
                                JSONObject ObjectData = responseArray.getJSONObject(i);

                                String groupName = ObjectData.getString("name");

                                JSONArray responseArrayStudent = ObjectData.getJSONArray("students");

                                ArrayList<Student> studentsInGroup = new ArrayList<>();

                                //Create String out of the Parsed JSON

                                for (int j = 0; j < responseArrayStudent.length(); j++) {
                                    JSONObject ObjectDataStudent = responseArrayStudent.getJSONObject(j);
                                    Integer studentId = ObjectDataStudent.getInt("student_id");
                                    String studentName = ObjectDataStudent.getString("name");
                                    String tagId = ObjectDataStudent.getString("tagId");

                                    Student student = new Student(studentName, studentId.toString(),tagId, false, "");
                                    studentsInGroup.add(student);
                                }

                                group = new Group(groupName, studentsInGroup);

                                Course course = new Course(courseName,  group);
                                courses.add(course);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                //Display error message whenever an error occurs
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        })

        {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }
        };

        // Access the RequestQueue through your singleton class.
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }
}
