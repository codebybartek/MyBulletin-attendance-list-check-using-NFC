package com.example.mybulletin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.mybulletin.objects.Course;
import com.example.mybulletin.objects.Professor;

import java.util.ArrayList;

public class SelectYourCourse extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner spinner;

    static Professor professor = MainActivity.professor1;
    static ArrayList<Course> courses = professor.getCourses();

    public static int courseSelected;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selct_your_course);

        int countCourses = courses.size();

        String[] courseName = new String[countCourses];

        for (int i = 0; i < countCourses; i++) {
            courseName[i]= courses.get(i).name;
        }

        final String[] paths = courseName;

        spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(SelectYourCourse.this,
                android.R.layout.simple_spinner_item, paths);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
        courseSelected = position;
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void onContinueClicked( View v) {
        intent = new Intent(this, Menu.class);
        startActivity(intent);

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
