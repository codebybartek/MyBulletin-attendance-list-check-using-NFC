package com.example.mybulletin.objects;

import java.util.ArrayList;

public class Exercise {
    public String data;
    public int hours;
    public  int startHour;
    public ArrayList<Student> studentsPresence = new ArrayList<>();

    public Exercise(String data, int hours, int startHour) {
        this.data = data;
        this.hours = hours;
        this.startHour = startHour;
    }

    public void setStudentsPresence(ArrayList<Student> studentsPresence) {
        this.studentsPresence = studentsPresence;
    }
}
